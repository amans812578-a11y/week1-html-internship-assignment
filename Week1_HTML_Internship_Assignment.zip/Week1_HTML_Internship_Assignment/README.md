# Week 1 HTML Fundamentals Assignment

This folder contains the completed HTML5 tasks and mini project.

## Files
- `task1_document_structure.html` — HTML5 document structure
- `task2_text_formatting.html` — headings, paragraphs and text formatting
- `task3_links_images_lists_tables.html` — links, image, lists and table
- `task4_student_registration_form.html` — student registration form
- `task5_semantic_html.html` — semantic HTML5 layout
- `task6_mini_project_student_portal.html` — combined HTML mini project
- `task7_reflection.txt` — learning reflection (150–200 words)

## How to run
1. Extract the ZIP folder.
2. Open the folder in Visual Studio Code.
3. Open any `.html` file.
4. Right-click and choose **Open with Live Server**, or double-click the HTML file to open it in a browser.

## Notes
- The assignment uses HTML5 only; no CSS or JavaScript is required.
- The sample banner images use an online placeholder service and need an internet connection.
- The registration forms are front-end demonstrations. They do not store or submit data to a server.
